import 'package:flutter_test/flutter_test.dart';
import 'package:weathernow/main.dart';

void main() {
  testWidgets('WeatherNow app starts and displays the home screen', (tester) async {
    await tester.pumpWidget(const WeatherNowApp());
    await tester.pump();
    expect(find.text('WeatherNow'), findsOneWidget);
    expect(find.text('Your cities'), findsOneWidget);
  });
}
