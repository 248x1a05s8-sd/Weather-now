# WeatherNow – Flutter Weather Application

## Topic
Weather application for searching a city, viewing current weather and a 7-day forecast, saving cities, and changing temperature units.

## Features
- Search city using Open-Meteo Geocoding API.
- Current temperature, feels-like temperature, humidity and wind speed.
- Seven-day forecast.
- Save and remove cities; saved city names persist after restart.
- Celsius/Fahrenheit setting persists after restart.
- Loading, error, retry and empty states.
- Validated city search form.
- Provider (`ChangeNotifier`) shared state.

## Data source
- Geocoding: https://geocoding-api.open-meteo.com/
- Weather forecast: https://api.open-meteo.com/
No API key is required for this learning project. Internet access is required.

## Project structure
- `lib/models`: weather data models
- `lib/services`: API communication
- `lib/providers`: shared application state
- `lib/screens`: Home, Add City, City Details and Settings
- `lib/widgets`: reusable weather icon widget

## Run the project
1. Install Flutter stable (3.35 or newer), Android Studio, Flutter/Dart plugins and JDK 17.
2. Extract this project folder.
3. Open a terminal in this folder.
4. Run:
   ```bash
   flutter pub get
   flutter doctor
   flutter run
   ```
5. Connect an Android phone with USB debugging enabled, or start an Android emulator.

## Test
```bash
flutter test
```

## Build release APK
```bash
flutter build apk --release
```
APK output: `build/app/outputs/flutter-apk/app-release.apk`

## GitHub
Create a public GitHub repository, then run:
```bash
git init
git add .
git commit -m "Initial WeatherNow Flutter project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```
Each member should make regular commits for the part they build.

## Team contribution (fill before submission)
- Member 1: [Name] – [Screens/features owned]
- Member 2: [Name] – [Screens/features owned]
- Member 3: [Name] – [Screens/features owned]

## Screenshots
Add at least three screenshots of the running application here before submission.

## Demonstration
Prepare a five-minute live demonstration on a physical Android phone. Show a rejected form entry and an error or empty state intentionally, explain one technical problem and its solution, and show the GitHub commit history and release APK.
