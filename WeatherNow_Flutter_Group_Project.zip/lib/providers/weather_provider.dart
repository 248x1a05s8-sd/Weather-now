import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/weather_data.dart';
import '../services/weather_service.dart';

class WeatherProvider extends ChangeNotifier {
  final WeatherService _service;
  WeatherProvider({WeatherService? service}) : _service = service ?? WeatherService();

  final List<WeatherData> _savedCities = [];
  bool _isLoading = false;
  String? _error;
  bool _fahrenheit = false;

  List<WeatherData> get savedCities => List.unmodifiable(_savedCities);
  bool get isLoading => _isLoading;
  String? get error => _error;
  bool get fahrenheit => _fahrenheit;

  String temperature(double celsius) =>
      '${_fahrenheit ? (celsius * 9 / 5 + 32).round() : celsius.round()}°${_fahrenheit ? 'F' : 'C'}';

  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    _fahrenheit = prefs.getBool('fahrenheit') ?? false;
    final cities = prefs.getStringList('saved_cities') ?? [];
    if (cities.isNotEmpty) {
      await refreshAll(cities);
    } else {
      notifyListeners();
    }
  }

  Future<void> searchAndSave(String cityName) async {
    if (cityName.trim().isEmpty) {
      _error = 'Please enter a city name.';
      notifyListeners();
      return;
    }
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final weather = await _service.searchWeather(cityName);
      final index = _savedCities.indexWhere((c) =>
          c.city.toLowerCase() == weather.city.toLowerCase() &&
          c.country.toLowerCase() == weather.country.toLowerCase());
      if (index >= 0) {
        _savedCities[index] = weather;
      } else {
        _savedCities.insert(0, weather);
      }
      await _persistCities();
    } catch (e) {
      _error = e.toString().replaceFirst('Exception: ', '');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> refreshAll([List<String>? names]) async {
    _isLoading = true;
    _error = null;
    notifyListeners();
    try {
      final requested = names ?? _savedCities.map((e) => e.city).toList();
      final refreshed = <WeatherData>[];
      for (final name in requested) {
        try {
          refreshed.add(await _service.searchWeather(name));
        } catch (_) {
          // Keep going so one unavailable city does not block the others.
        }
      }
      _savedCities
        ..clear()
        ..addAll(refreshed);
      if (refreshed.isEmpty && requested.isNotEmpty) {
        _error = 'Could not load saved cities. Check your internet connection.';
      }
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> removeCity(WeatherData city) async {
    _savedCities.removeWhere((c) => c.city == city.city && c.country == city.country);
    await _persistCities();
    notifyListeners();
  }

  Future<void> setFahrenheit(bool value) async {
    _fahrenheit = value;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('fahrenheit', value);
    notifyListeners();
  }

  Future<void> _persistCities() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('saved_cities', _savedCities.map((e) => e.city).toList());
  }
}
