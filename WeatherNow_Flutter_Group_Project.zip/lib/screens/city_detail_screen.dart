import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/weather_data.dart';
import '../providers/weather_provider.dart';
import '../widgets/weather_icon.dart';

class CityDetailScreen extends StatelessWidget {
  final WeatherData city;
  const CityDetailScreen({super.key, required this.city});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WeatherProvider>();
    return Scaffold(
      appBar: AppBar(title: Text(city.city)),
      body: ListView(padding: const EdgeInsets.all(18), children: [
        Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [
          Text('${city.city}, ${city.country}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          WeatherIcon(code: city.weatherCode, size: 64),
          Text(provider.temperature(city.temperature), style: const TextStyle(fontSize: 52, fontWeight: FontWeight.bold)),
          Text(descriptionForWeather(city.weatherCode), style: const TextStyle(fontSize: 18)),
          const SizedBox(height: 18),
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            _Metric(icon: Icons.thermostat, label: 'Feels like', value: provider.temperature(city.feelsLike)),
            _Metric(icon: Icons.water_drop_outlined, label: 'Humidity', value: '${city.humidity}%'),
            _Metric(icon: Icons.air, label: 'Wind', value: '${city.windSpeed.round()} km/h'),
          ]),
        ]))),
        const SizedBox(height: 18),
        const Text('7-day forecast', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        for (final day in city.forecast)
          Card(child: ListTile(
            leading: WeatherIcon(code: day.code),
            title: Text(DateFormat('EEEE').format(day.date)),
            subtitle: Text(DateFormat('d MMM').format(day.date)),
            trailing: Text('${provider.temperature(day.max)} / ${provider.temperature(day.min)}', style: const TextStyle(fontWeight: FontWeight.w600)),
          )),
      ]),
    );
  }
}

class _Metric extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _Metric({required this.icon, required this.label, required this.value});
  @override
  Widget build(BuildContext context) => Column(children: [
    Icon(icon, color: Theme.of(context).colorScheme.primary),
    const SizedBox(height: 4),
    Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
    Text(label, style: const TextStyle(fontSize: 11, color: Colors.black54)),
  ]);
}
