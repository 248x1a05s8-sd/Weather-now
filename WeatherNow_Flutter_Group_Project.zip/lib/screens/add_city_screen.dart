import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';

class AddCityScreen extends StatefulWidget {
  const AddCityScreen({super.key});
  @override
  State<AddCityScreen> createState() => _AddCityScreenState();
}

class _AddCityScreenState extends State<AddCityScreen> {
  final _formKey = GlobalKey<FormState>();
  final _controller = TextEditingController();

  @override
  void dispose() { _controller.dispose(); super.dispose(); }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    final provider = context.read<WeatherProvider>();
    await provider.searchAndSave(_controller.text);
    if (!mounted) return;
    if (provider.error == null) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WeatherProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Add a city')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Icon(Icons.travel_explore, size: 64),
        const SizedBox(height: 16),
        const Text('Find weather anywhere', textAlign: TextAlign.center, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Enter a city name to get its current weather and 7-day forecast.', textAlign: TextAlign.center),
        const SizedBox(height: 24),
        Form(
          key: _formKey,
          child: TextFormField(
            controller: _controller,
            textInputAction: TextInputAction.search,
            onFieldSubmitted: (_) => _submit(),
            decoration: const InputDecoration(labelText: 'City name', hintText: 'e.g. Guntur', prefixIcon: Icon(Icons.location_city), border: OutlineInputBorder()),
            validator: (value) {
              final text = value?.trim() ?? '';
              if (text.isEmpty) return 'Please enter a city name.';
              if (text.length < 2) return 'Enter at least 2 characters.';
              if (text.length > 60) return 'City name is too long.';
              return null;
            },
          ),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: provider.isLoading ? null : _submit,
          icon: provider.isLoading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.search),
          label: Text(provider.isLoading ? 'Searching...' : 'Search weather'),
        ),
        if (provider.error != null) Padding(padding: const EdgeInsets.only(top: 14), child: Text(provider.error!, style: const TextStyle(color: Colors.red))),
      ]),
    );
  }
}
