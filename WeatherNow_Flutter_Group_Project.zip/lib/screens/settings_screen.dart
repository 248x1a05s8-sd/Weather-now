import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final provider = context.watch<WeatherProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Preferences', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        Card(child: SwitchListTile(
          title: const Text('Use Fahrenheit'),
          subtitle: Text(provider.fahrenheit ? 'Temperatures displayed in °F' : 'Temperatures displayed in °C'),
          secondary: const Icon(Icons.thermostat),
          value: provider.fahrenheit,
          onChanged: provider.setFahrenheit,
        )),
        const Card(child: ListTile(
          leading: Icon(Icons.info_outline),
          title: Text('Weather data'),
          subtitle: Text('Powered by Open-Meteo. Forecasts are retrieved over the internet.'),
        )),
        const Card(child: ListTile(
          leading: Icon(Icons.cloud_outlined),
          title: Text('WeatherNow'),
          subtitle: Text('Flutter group project'),
        )),
      ]),
    );
  }
}
