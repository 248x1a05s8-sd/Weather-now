import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/weather_provider.dart';
import '../models/weather_data.dart';
import '../widgets/weather_icon.dart';
import 'add_city_screen.dart';
import 'city_detail_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final weather = context.watch<WeatherProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('WeatherNow', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(tooltip: 'Settings', onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())), icon: const Icon(Icons.settings_outlined)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AddCityScreen())),
        icon: const Icon(Icons.add),
        label: const Text('Add city'),
      ),
      body: RefreshIndicator(
        onRefresh: weather.refreshAll,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
          children: [
            const Text('Your cities', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Check current conditions and the week ahead.'),
            const SizedBox(height: 18),
            if (weather.isLoading && weather.savedCities.isEmpty)
              const Padding(padding: EdgeInsets.all(40), child: Center(child: CircularProgressIndicator())),
            if (weather.error != null)
              Card(child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(weather.error!, style: const TextStyle(color: Colors.red)),
                  const SizedBox(height: 8),
                  TextButton.icon(onPressed: weather.refreshAll, icon: const Icon(Icons.refresh), label: const Text('Retry')),
                ]),
              )),
            if (!weather.isLoading && weather.savedCities.isEmpty && weather.error == null)
              const Card(child: Padding(
                padding: EdgeInsets.all(24),
                child: Column(children: [
                  Icon(Icons.location_city, size: 48),
                  SizedBox(height: 10),
                  Text('No saved cities yet', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  Text('Tap “Add city” to search for your first city.'),
                ]),
              )),
            for (final city in weather.savedCities) _CityCard(city: city),
          ],
        ),
      ),
    );
  }
}

class _CityCard extends StatelessWidget {
  final WeatherData city;
  const _CityCard({required this.city});

  @override
  Widget build(BuildContext context) {
    final provider = context.read<WeatherProvider>();
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => CityDetailScreen(city: city))),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            WeatherIcon(code: city.weatherCode, size: 42),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(city.city, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text(city.country),
              Text(descriptionForWeather(city.weatherCode), style: const TextStyle(color: Colors.black54)),
            ])),
            Text(provider.temperature(city.temperature), style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w600)),
            PopupMenuButton<String>(
              onSelected: (value) { if (value == 'remove') provider.removeCity(city); },
              itemBuilder: (_) => const [PopupMenuItem(value: 'remove', child: Text('Remove city'))],
            ),
          ]),
        ),
      ),
    );
  }
}
