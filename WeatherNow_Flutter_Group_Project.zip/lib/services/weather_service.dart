import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/weather_data.dart';

class CityLocation {
  final String name;
  final String country;
  final double latitude;
  final double longitude;
  const CityLocation(this.name, this.country, this.latitude, this.longitude);
}

class WeatherService {
  Future<CityLocation> findCity(String query) async {
    final uri = Uri.https('geocoding-api.open-meteo.com', '/v1/search', {
      'name': query,
      'count': '1',
      'language': 'en',
      'format': 'json',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('Could not search for the city. Please try again.');
    }
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    final results = body['results'] as List?;
    if (results == null || results.isEmpty) {
      throw Exception('City not found. Check the spelling and try again.');
    }
    final item = results.first as Map<String, dynamic>;
    return CityLocation(
      item['name'] as String,
      (item['country'] ?? '') as String,
      (item['latitude'] as num).toDouble(),
      (item['longitude'] as num).toDouble(),
    );
  }

  Future<WeatherData> getWeather(CityLocation city) async {
    final uri = Uri.https('api.open-meteo.com', '/v1/forecast', {
      'latitude': city.latitude.toString(),
      'longitude': city.longitude.toString(),
      'current': 'temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m',
      'daily': 'weather_code,temperature_2m_max,temperature_2m_min',
      'timezone': 'auto',
      'forecast_days': '7',
    });
    final response = await http.get(uri).timeout(const Duration(seconds: 15));
    if (response.statusCode != 200) {
      throw Exception('Weather service is unavailable. Please retry.');
    }
    final json = jsonDecode(response.body) as Map<String, dynamic>;
    return WeatherData.fromJson(city.name, city.country, city.latitude, city.longitude, json);
  }

  Future<WeatherData> searchWeather(String query) async {
    final city = await findCity(query.trim());
    return getWeather(city);
  }
}
