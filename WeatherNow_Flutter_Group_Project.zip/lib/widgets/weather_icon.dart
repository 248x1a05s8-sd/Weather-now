import 'package:flutter/material.dart';

IconData iconForWeather(int code) {
  if (code == 0) return Icons.wb_sunny_rounded;
  if ([1, 2].contains(code)) return Icons.cloud_queue_rounded;
  if (code == 3) return Icons.cloud_rounded;
  if ([45, 48].contains(code)) return Icons.foggy;
  if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].contains(code)) return Icons.water_drop_rounded;
  if ([71, 73, 75, 77, 85, 86].contains(code)) return Icons.ac_unit_rounded;
  if ([95, 96, 99].contains(code)) return Icons.thunderstorm_rounded;
  return Icons.cloud_outlined;
}

String descriptionForWeather(int code) {
  if (code == 0) return 'Clear sky';
  if ([1, 2].contains(code)) return 'Partly cloudy';
  if (code == 3) return 'Overcast';
  if ([45, 48].contains(code)) return 'Fog';
  if ([51, 53, 55, 61, 63, 65, 80, 81, 82].contains(code)) return 'Rain';
  if ([71, 73, 75, 77, 85, 86].contains(code)) return 'Snow';
  if ([95, 96, 99].contains(code)) return 'Thunderstorm';
  return 'Cloudy';
}

class WeatherIcon extends StatelessWidget {
  final int code;
  final double size;
  const WeatherIcon({super.key, required this.code, this.size = 34});
  @override
  Widget build(BuildContext context) => Icon(iconForWeather(code), size: size, color: Theme.of(context).colorScheme.primary);
}
