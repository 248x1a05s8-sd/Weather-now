class WeatherData {
  final String city;
  final String country;
  final double latitude;
  final double longitude;
  final double temperature;
  final double feelsLike;
  final int humidity;
  final double windSpeed;
  final int weatherCode;
  final List<DailyForecast> forecast;

  const WeatherData({
    required this.city,
    required this.country,
    required this.latitude,
    required this.longitude,
    required this.temperature,
    required this.feelsLike,
    required this.humidity,
    required this.windSpeed,
    required this.weatherCode,
    required this.forecast,
  });

  factory WeatherData.fromJson(
    String city,
    String country,
    double latitude,
    double longitude,
    Map<String, dynamic> json,
  ) {
    final current = json['current'] as Map<String, dynamic>;
    final daily = json['daily'] as Map<String, dynamic>;
    final dates = (daily['time'] as List).cast<String>();
    final max = (daily['temperature_2m_max'] as List).cast<num>();
    final min = (daily['temperature_2m_min'] as List).cast<num>();
    final codes = (daily['weather_code'] as List).cast<num>();

    return WeatherData(
      city: city,
      country: country,
      latitude: latitude,
      longitude: longitude,
      temperature: (current['temperature_2m'] as num).toDouble(),
      feelsLike: (current['apparent_temperature'] as num).toDouble(),
      humidity: (current['relative_humidity_2m'] as num).round(),
      windSpeed: (current['wind_speed_10m'] as num).toDouble(),
      weatherCode: (current['weather_code'] as num).toInt(),
      forecast: List.generate(dates.length, (i) => DailyForecast(
        date: DateTime.parse(dates[i]),
        max: max[i].toDouble(),
        min: min[i].toDouble(),
        code: codes[i].toInt(),
      )),
    );
  }
}

class DailyForecast {
  final DateTime date;
  final double max;
  final double min;
  final int code;
  const DailyForecast({required this.date, required this.max, required this.min, required this.code});
}
