# Defect Log – WeatherNow

Record defects found during testing. Do not claim these checks passed until they have been performed on a device.

| ID | Defect / scenario | Steps to reproduce | Status |
|---|---|---|---|
| D-001 | No internet connection | Disable Wi-Fi/mobile data and search for a city | To test |
| D-002 | City does not exist | Search for a random/invalid city name | To test |
| D-003 | Empty city field | Submit the form without entering a city | To test |
| D-004 | Very long city input | Paste more than 60 characters into the city field | To test |
| D-005 | Repeated fast taps | Tap Search repeatedly while a request is running | To test |
| D-006 | Screen rotation | Rotate the phone while viewing a forecast | To test |
